import random
import time

print("test")
text = input("your text: ")
print(f"you saied: {text}")
        
def number():
    while True:
        num = random.randint(1, 6)
        print(f"Your number was {num}")
        time.sleep(2)
        print("do you want to generate again? [Y/N]")
        ynm = input("You: ")
        if ynm == "Y":
            pass
        elif ynm == "N":
            break
            exit()
        else:
            print("invalid option")

while True:
    print("Do you want to generate a number between 1 and 6? [Y/N]")
    yn = input("You: ")
    if yn == "Y":
        number()
        break
    elif yn == "N":
        exit()
    else:
        print("invalid option")